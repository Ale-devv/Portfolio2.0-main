import React from "react";
import * as S from "./style";

const ComponentName = () => {
	return <div></div>;
};

export default ComponentName;
