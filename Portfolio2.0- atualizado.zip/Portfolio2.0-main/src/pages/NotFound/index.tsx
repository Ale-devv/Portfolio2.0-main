import React from "react";
import * as S from "./style";

const NotFound: React.FC = () => {
	return <div>NotFound</div>;
};

export default NotFound;
