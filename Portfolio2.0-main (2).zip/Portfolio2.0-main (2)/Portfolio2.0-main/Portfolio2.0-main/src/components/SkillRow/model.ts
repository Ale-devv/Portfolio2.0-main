export interface SkillRowModel {
    name: string;
    description: string;
    svg: string;
}
