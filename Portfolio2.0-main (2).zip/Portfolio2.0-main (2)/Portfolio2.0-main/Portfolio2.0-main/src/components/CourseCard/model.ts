export interface CourseCardModel {
    courseName: string;
    institution: string;
    duration: string;
    instructor: string;
    conclusion: string;
    certificate: string;
}